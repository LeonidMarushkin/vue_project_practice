<template>
  <div class="header">
    <h1 class="header__title">наша продукция</h1>
    <div class="header__cart">
      <div class="header__text">
        <span>{{ basketCount.length }} товара</span>
        <span>на сумму {{ basketCount.reduce((a, b) => a + b.price, 0) }} ₽</span>
      </div>
      <router-link to="/basket">
        <ButtonCartComponent />
      </router-link>
    </div>
  </div>
</template>

<script>
// import { ref } from 'vue'
import { useStore } from 'vuex';
import ButtonCartComponent from '../ui/ButtonCartComponent.vue';
import { computed } from 'vue';

export default {
  name: 'HeaderMainComponent',

  components: {
    ButtonCartComponent
  },

  props: {
  },

  methods: {
  },

  setup() {
    const store = useStore();

    const basketCount = computed(() => {
      return store.getters.getBasketGoods
    })

    // const basketSum = computed(()=> {

    // })
    return {
      basketCount,
      // basketSum
    }
  }
}
</script>

<style lang="scss" scoped>
.header {
  display: flex;
  flex-direction: row;
  justify-content: space-around;
}

.header__title {
  color: #FFF;
  font-family: Montserrat;
  font-size: 31px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
  text-transform: uppercase;
}

.header__text {
  color: #FFF;
  text-align: right;
  font-family: Montserrat;
  font-size: 17px;
  font-style: normal;
  font-weight: 500;
  line-height: normal;
  display: flex;
  align-items: flex-end;
  flex-direction: column;
}

.header__cart {
  display: flex;
  flex-direction: row;
  gap: 20px;
  align-items: center;
}
</style>
