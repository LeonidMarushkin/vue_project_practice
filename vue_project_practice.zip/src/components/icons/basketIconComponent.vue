<template>
  <div class=""></div>
</template>

<script>
// import { ref } from 'vue'

export default {
  name: 'basketIconComponent',
  components: {
  },
  props: {
  },
  setup () {
  }
}
</script>

<style lang="scss" scoped>

</style>
